graph = {
  '1' : ['4', '2'],
  '4' : ['3'],
  '2' : ['5', '7', '8'],
  '3' : ['10', '9'],
  '5' : ['6'],
  '7' : [],
  '8' : [],
  '10' : [],
  '9' : [],
  '6' : [],
}

visited = [] 
queue = []     

def bfs(visited, graph, node): 
  visited.append(node)
  queue.append(node)

  while queue:          
    m = queue.pop(0) 
    print (m, end = " ") 

    for neighbour in graph[m]:
      if neighbour not in visited:
        visited.append(neighbour)
        queue.append(neighbour)


print("Hasil BFS")
bfs(visited, graph, '1')   