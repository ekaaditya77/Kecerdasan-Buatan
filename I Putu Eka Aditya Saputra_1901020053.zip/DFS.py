graph = {
  '1' : ['4'],
  '4' : ['3'],
  '3' : ['10', '9', '2'],
  '10' : [],
  '9' : [],
  '2' : ['8'],
  '8' : ['7'],
  '7' : ['5'],
  '5' : ['6'],
  '6' : [],
}

visited = set()

def dfs(visited, graph, node):  
    if node not in visited:
        print (node)
        visited.add(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)

print("Jalur dari DFS adalah")
dfs(visited, graph, '1')